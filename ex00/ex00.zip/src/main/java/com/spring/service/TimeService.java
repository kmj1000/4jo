package com.spring.service;

public interface TimeService {

	String getTime2();

}
