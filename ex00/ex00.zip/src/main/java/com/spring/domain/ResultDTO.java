package com.spring.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResultDTO {
	private int user_cnt;
	private String msg;
}
