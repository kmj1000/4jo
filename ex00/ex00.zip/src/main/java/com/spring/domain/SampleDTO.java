package com.spring.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@AllArgsConstructor
@Setter
@Getter
public class SampleDTO {
	private String name;
	private int age;
	
	
	public SampleDTO() {
		
	}
	
}
