package com.spring.test;

import org.springframework.stereotype.Component;

@Component
public class People {

}
