console.log('안녕 나 js_ex1.js 야');

function sayHello(){
    alert('잘지내니?');
}