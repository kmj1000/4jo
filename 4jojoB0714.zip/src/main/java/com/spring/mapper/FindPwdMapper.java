package com.spring.mapper;

import com.spring.domain.MembersDTO;

public interface FindPwdMapper {


	String findPwd(MembersDTO mdto);

	
}
