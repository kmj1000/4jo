package com.spring.mapper;

import com.spring.domain.MembersDTO;

public interface JoinMapper {

	int registerMembers(MembersDTO mdto);

}
