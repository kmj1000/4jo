package com.spring.mapper;

import com.spring.domain.MembersDTO;

public interface FindEmailMapper {
	String findEmail(MembersDTO mdto);

}
