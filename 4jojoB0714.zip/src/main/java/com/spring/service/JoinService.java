package com.spring.service;

import com.spring.domain.MembersDTO;

public interface JoinService {
	int registerMembers(MembersDTO mdto);
}
