package com.spring.service;

import com.spring.domain.MembersDTO;

public interface FindEmailService {

	String findEmail(MembersDTO mdto);
	
}
